import { NextResponse } from "next/server";
import prisma from "@zyra/database/src/client";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { Prisma } from "@prisma/client";

// Helper to convert snake_case to camelCase for Prisma field names
function convertToCamelCase(snakeCase: string): string {
  // Map common snake_case field names to their camelCase equivalents
  const fieldNameMap: Record<string, string> = {
    started_at: "startedAt",
    finished_at: "finishedAt",
    created_at: "createdAt",
    updated_at: "updatedAt",
    workflow_id: "workflowId",
    user_id: "userId",
    trigger_type: "triggerType",
    trigger_data: "triggerData",
  };

  return fieldNameMap[snakeCase] || snakeCase;
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const workflowId = searchParams.get("workflowId");
  const limit = parseInt(searchParams.get("limit") || "10", 10);
  const offset = parseInt(searchParams.get("offset") || "0", 10);
  const sortField = searchParams.get("sort") || "startedAt";
  const order = (searchParams.get("order") || "desc") as "asc" | "desc";
  const status = searchParams.get("status");

  // Convert sort field from snake_case to camelCase if needed
  const sort = convertToCamelCase(sortField);

  // Validate session
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  if (!workflowId) {
    return NextResponse.json({ error: "Missing workflowId" }, { status: 400 });
  }

  try {
    // Verify user has access to this workflow
    const workflow = await prisma.workflow.findFirst({
      where: {
        id: workflowId,
        userId: session.user.id,
      },
      select: {
        id: true,
      },
    });

    if (!workflow) {
      return NextResponse.json(
        { error: "Workflow not found or access denied" },
        { status: 404 }
      );
    }

    // Build the where clause
    const whereClause: Prisma.WorkflowExecutionWhereInput = {
      workflowId: workflowId,
    };

    // Add status filter if provided and not 'all'
    if (status && status !== "all") {
      // Cast the status to the appropriate type that Prisma expects
      whereClause.status =
        status as Prisma.WorkflowExecutionWhereInput["status"];
    }

    // Count total matching executions for pagination
    const total = await prisma.workflowExecution.count({
      where: whereClause,
    });

    // Fetch workflow executions with pagination and sorting
    const executions = await prisma.workflowExecution.findMany({
      where: whereClause,
      include: {
        executionLogs: true,
        nodeExecutions: true,
        blockExecutions: true,
      },
      orderBy: {
        [sort]: order,
      },
      take: limit,
      skip: offset,
    });

    // Format the response to match the expected structure in the frontend
    const formattedExecutions = executions.map((exec) => ({
      id: exec.id,
      workflow_id: exec.workflowId,
      status: exec.status,
      started_at: exec.startedAt?.toISOString(),
      finished_at: exec.finishedAt?.toISOString(),
      error: exec.error,
      user_id: exec.userId,
      created_at: exec.createdAt?.toISOString(),
      updated_at: exec.updatedAt?.toISOString(),
      trigger_type: exec.triggerType,
      trigger_data: exec.triggerData,
    }));

    return NextResponse.json({
      executions: formattedExecutions,
      total,
    });
  } catch (error) {
    console.error("Error fetching workflow executions:", error);
    return NextResponse.json(
      { error: "Failed to fetch workflow executions" },
      { status: 500 }
    );
  }
}
